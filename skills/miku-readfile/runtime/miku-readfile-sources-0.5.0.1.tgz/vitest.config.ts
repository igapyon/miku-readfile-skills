import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["test/**/*.test.ts"],
    exclude: ["workplace/**", "node_modules/**", "dist/**", "bundle/**"],
  },
});
